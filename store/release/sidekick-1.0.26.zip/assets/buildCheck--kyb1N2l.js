const e="mwtwoy8s";function n(t){return t.build!==void 0?t.build!==e:t.error?.includes("Unknown message type")===!0}export{e as B,n as b};
