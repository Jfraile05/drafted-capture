const n="mwsl2b03";function r(e){return e.build!==void 0?e.build!==n:e.error?.includes("Unknown message type")===!0}export{n as B,r as b};
