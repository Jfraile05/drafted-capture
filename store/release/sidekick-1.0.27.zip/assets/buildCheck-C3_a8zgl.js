const e="mwuy7zgv";function n(u){return u.build!==void 0?u.build!==e:u.error?.includes("Unknown message type")===!0}export{e as B,n as b};
