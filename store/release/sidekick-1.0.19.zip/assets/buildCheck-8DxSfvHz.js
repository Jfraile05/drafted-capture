const n="mwoccz17";function o(e){return e.build!==void 0?e.build!==n:e.error?.includes("Unknown message type")===!0}export{n as B,o as b};
