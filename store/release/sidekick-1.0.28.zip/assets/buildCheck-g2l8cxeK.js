const e="mx0s3rbh";function n(r){return r.build!==void 0?r.build!==e:r.error?.includes("Unknown message type")===!0}export{e as B,n as b};
