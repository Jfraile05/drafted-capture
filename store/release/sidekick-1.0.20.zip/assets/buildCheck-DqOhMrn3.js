const e="mwqr1v4v";function n(r){return r.build!==void 0?r.build!==e:r.error?.includes("Unknown message type")===!0}export{e as B,n as b};
