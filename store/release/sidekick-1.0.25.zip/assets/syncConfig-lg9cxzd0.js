const e={alarmName:"drafted-sync",recoveryMinutes:1,retryBaseMs:6e4,retryMaxMs:9e5};export{e as S};
