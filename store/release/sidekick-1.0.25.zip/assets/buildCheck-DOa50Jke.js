const t="mwtr52p7";function e(r){return r.build!==void 0?r.build!==t:r.error?.includes("Unknown message type")===!0}export{t as B,e as b};
