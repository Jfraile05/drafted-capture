const u="mwn6bbec",i="build_reload_at";function s(e,n,r,o){return n||r!==void 0&&o-r<6e4?!1:e.build!==void 0?e.build!==u:e.error?.includes("Unknown message type")===!0}export{i as B,u as a,s};
