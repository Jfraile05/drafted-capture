const i="mwo39g3j",n="build_reload_at";function s(e,r,o,u){return r||o!==void 0&&u-o<6e4?!1:e.build!==void 0?e.build!==i:e.error?.includes("Unknown message type")===!0}export{n as B,i as a,s};
